// ============================================================
// KRUIZLY — BOOKING PAGE
// ============================================================

import { checkAuth, getCurrentUser } from "./auth.js?v=20260917-v1";
import { api } from "./kruizly-api.js?v=20261001-v2";
import "./nav-helper.js?v=20260930-v7";
import { generateNumericBookingId } from "./booking-reference.js";
import {
  calculateBookingPrice,
  calculateDuration,
  formatCurrency,
  formatHumanDateTime,
  parseDateTime,
} from "./booking-calculator.js?v=20261015-v12";
import { validateCoupon } from "./coupon-service.js";

function padDatePart(value) {
  return String(value).padStart(2, "0");
}

function toLocalDateTime(date) {
  return (
    date.getFullYear() +
    "-" +
    padDatePart(date.getMonth() + 1) +
    "-" +
    padDatePart(date.getDate()) +
    "T" +
    padDatePart(date.getHours()) +
    ":" +
    padDatePart(date.getMinutes())
  );
}

function sessionStorageGet(key) {
  try {
    return sessionStorage.getItem(key);
  } catch {
    return null;
  }
}

const params = new URLSearchParams(window.location.search);
let queryId =
  params.get("id") ||
  params.get("car") ||
  params.get("reg") ||
  params.get("vehicle") ||
  sessionStorageGet("crp_selectedCarId") ||
  sessionStorageGet("crp_lastVehicleId");
if (queryId === "undefined" || queryId === "null" || queryId === "")
  queryId = null;

const form = document.getElementById("bookingForm");
const totalsEl = document.getElementById("bookingTotals");
const statusEl = document.getElementById("bookingStatus");
const bookingTitle = document.getElementById("bookingTitle");
const vehicleImage = document.getElementById("bookingVehicleImage");
const vehicleIcon = document.getElementById("bookingVehicleIcon");
const vehicleName = document.getElementById("bookingVehicleName");
const vehicleMeta = document.getElementById("bookingVehicleMeta");
const dayRate = document.getElementById("bookingDayRate");
const driverRate = document.getElementById("bookingDriverRate");
const deposit = document.getElementById("bookingDeposit");
const location = document.getElementById("bookingLocation");
const licenseNote = document.getElementById("bookingLicenseNote");

function showUnavailable(message) {
  if (bookingTitle) bookingTitle.textContent = "Car Not Available";
  if (vehicleName) vehicleName.textContent = message;
  if (vehicleMeta) vehicleMeta.textContent = "";
  if (form) form.hidden = true;
}

async function resolveAndInitVehicle() {
  if (bookingTitle) bookingTitle.textContent = "Loading vehicle...";

  // Wait for the authoritative fleet from database
  if (window.fleetLoadingPromise) {
    try {
      await window.fleetLoadingPromise;
    } catch (_) {}
  }

  let catalog = Array.isArray(window.fleetVehicles) ? window.fleetVehicles : [];
  if (!catalog.length) {
    try {
      const res = await api.get("/vehicles");
      if (Array.isArray(res?.vehicles)) {
        catalog = res.vehicles;
      }
    } catch (_) {}
  }

  let matched = null;
  if (queryId) {
    const qStr = String(queryId).toLowerCase().trim();
    // 1. Exact registration match (e.g. MH02FU6808)
    matched = catalog.find(
      (v) => v.regNo && String(v.regNo).toLowerCase().trim() === qStr
    );
    // 2. Exact carId match (e.g. CRP-009)
    if (!matched) {
      matched = catalog.find(
        (v) => v.carId && String(v.carId).toLowerCase().trim() === qStr
      );
    }
    // 3. Exact database ID match
    if (!matched) {
      matched = catalog.find(
        (v) =>
          v.id &&
          (String(v.id).toLowerCase() === qStr ||
            String(v.id).replace(/\D/g, "") === qStr)
      );
    }
    // 4. Exact brand + model match
    if (!matched) {
      matched = catalog.find(
        (v) =>
          `${v.brand} ${v.model}`.toLowerCase() === qStr ||
          (v.slug && String(v.slug).toLowerCase() === qStr)
      );
    }
  }

  if (!matched && catalog.length > 0) {
    matched =
      catalog.find(
        (v) => v.available !== false && v.status !== "unavailable"
      ) || catalog[0];
  }

  if (!matched) {
    showNoVehicleSelected();
    return;
  }

  if (matched.available === false || matched.status === "unavailable") {
    if (vehicleName)
      vehicleName.textContent = `${matched.brand} ${matched.model}`;
    showUnavailable(
      "This car is currently booked. Please choose another vehicle from the fleet."
    );
    return;
  }

  try {
    sessionStorage.setItem("crp_selectedCarId", matched.regNo || matched.id);
  } catch (_) {}

  initBooking(matched);
}

resolveAndInitVehicle();

function showNoVehicleSelected() {
  if (bookingTitle) bookingTitle.textContent = "No Vehicle Selected";
  showUnavailable(
    "Please choose a vehicle from our fleet to start your rental booking.",
  );
  const bookContainer = document.querySelector(".booking-layout") || document.querySelector(".booking-panel") || form?.parentElement;
  if (bookContainer && !document.getElementById("btnReturnToFleet")) {
    const btnFleet = document.createElement("a");
    btnFleet.id = "btnReturnToFleet";
    btnFleet.href = "fleet.html";
    btnFleet.style.cssText = "display:inline-block;margin-top:20px;padding:12px 24px;text-align:center;text-decoration:none;border-radius:8px;font-weight:700;background:var(--kz-primary,#ffb703);color:#000;";
    btnFleet.textContent = "Browse Fleet & Choose Car";
    bookContainer.appendChild(btnFleet);
  }
}

async function initBooking(vehicle) {
  let currentUser = null;
  let appliedCoupons = [];

  if (bookingTitle)
    bookingTitle.textContent =
      "Book the " + vehicle.brand + " " + vehicle.model;
  if (vehicleName)
    vehicleName.textContent = vehicle.brand + " " + vehicle.model;
  if (vehicleMeta)
    vehicleMeta.textContent =
      vehicle.category + " • " + vehicle.transmission + " • " + vehicle.fuel;
  if (dayRate) dayRate.textContent = "₹" + formatCurrency(vehicle.priceDay);
  if (driverRate)
    driverRate.textContent = "₹" + formatCurrency(vehicle.driverPrice || 2000);
  if (deposit)
    deposit.textContent = "₹" + formatCurrency(vehicle.securityDeposit);
  const resolvedHubName = vehicle.hubName || vehicle.location || (String(vehicle.hubId || vehicle.hub_id) === "2" ? "Kandivali Hub, Mumbai" : "Gavson Business Park, Ghansoli, Navi Mumbai");
  if (location)
    location.textContent = resolvedHubName;

  const imagePath = window.fleetImagePath ? window.fleetImagePath(vehicle) : "";
  if (imagePath && vehicleImage) {
    const img = document.createElement("img");
    img.src = imagePath;
    img.alt = vehicle.brand + " " + vehicle.model;
    img.loading = "eager";
    img.decoding = "async";
    img.onload = () => {
      if (vehicleIcon) vehicleIcon.style.display = "none";
      vehicleImage.classList.add("has-image");
    };
    img.onerror = () => {
      if (vehicleIcon) vehicleIcon.style.display = "block";
    };
    vehicleImage.appendChild(img);
  }

  const pickupInput = document.getElementById("pickupDate");
  const dropInput = document.getElementById("dropDate");
  const driverInput = document.getElementById("withDriver");
  const paymentPlanInputs = Array.from(
    document.querySelectorAll('input[name="paymentPlan"]'),
  );
  const submitBtn = document.getElementById("bookingSubmitBtn");
  const couponInput = document.getElementById("couponInput");
  const couponApplyBtn = document.getElementById("couponApplyBtn");
  const couponMsg = document.getElementById("couponMsg");
  const appliedCouponsWrap = document.getElementById("appliedCouponsWrap");
  const couponSuggestionsGrid = document.getElementById(
    "couponSuggestionsGrid",
  );
  const resetBookingTimes = document.getElementById("resetBookingTimes");

  function renderAppliedCoupons() {
    if (!appliedCouponsWrap) return;
    if (appliedCoupons.length === 0) {
      appliedCouponsWrap.innerHTML = "";
      appliedCouponsWrap.hidden = true;
      return;
    }

    appliedCouponsWrap.hidden = false;
    appliedCouponsWrap.innerHTML = appliedCoupons
      .filter((c) => Boolean(c && (c.code || c.couponCode)))
      .map((c) => {
        const type = c.discountType || c.discount_type || c.type || "flat";
        const val = Number(c.discountValue ?? c.discount_value ?? c.val ?? 0);
        const discountTxt =
          type === "percent" || type === "percentage"
            ? `${val}% OFF`
            : `₹${val} OFF`;
        const code = c.code || c.couponCode;
        return `
        <span class="applied-coupon-tag">
          <strong>${code}</strong> (${discountTxt})
          <button type="button" class="remove-coupon-btn" data-code="${code}" aria-label="Remove coupon ${code}">✕</button>
        </span>
      `;
      })
      .join("");

    appliedCouponsWrap.querySelectorAll(".remove-coupon-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const codeToRemove = btn.dataset.code;
        appliedCoupons = appliedCoupons.filter((c) => c.code !== codeToRemove);
        if (couponMsg) {
          couponMsg.textContent = `Coupon ${codeToRemove} removed.`;
          couponMsg.className = "booking-coupon-msg";
        }
        calculateBooking();
        renderAppliedCoupons();
      });
    });
  }

  async function applyCouponCode(rawCode) {
    const code = String(rawCode || "")
      .trim()
      .toUpperCase();
    if (!code) {
      if (couponMsg) {
        couponMsg.textContent = "Please enter a coupon code.";
        couponMsg.className = "booking-coupon-msg error";
      }
      return;
    }

    if (appliedCoupons.some((c) => c.code === code)) {
      if (couponMsg) {
        couponMsg.textContent = `Coupon ${code} is already applied.`;
        couponMsg.className = "booking-coupon-msg";
      }
      return;
    }

    if (couponApplyBtn) couponApplyBtn.disabled = true;
    if (couponMsg) {
      couponMsg.textContent = "Verifying coupon...";
      couponMsg.className = "booking-coupon-msg";
    }

    const baseCalc = calculateBookingPrice({
      vehicle,
      pickup: pickupInput.value,
      drop: dropInput.value,
      withDriver: Boolean(driverInput && driverInput.checked),
      coupon: null,
    });

    const result = await validateCoupon({
      code,
      bookingAmount: baseCalc.rentalTotal || 0,
      userId: currentUser?.uid,
      appliedCoupons,
    });

    if (couponApplyBtn) couponApplyBtn.disabled = false;

    if (result.valid && result.coupon) {
      appliedCoupons.push(result.coupon);
      if (couponInput) couponInput.value = "";
      if (couponMsg) {
        couponMsg.textContent = `Coupon '${code}' applied! (${result.coupon.label})`;
        couponMsg.className = "booking-coupon-msg success";
      }
      calculateBooking();
      renderAppliedCoupons();
    } else {
      if (couponMsg) {
        couponMsg.textContent = result.error || "Coupon could not be applied.";
        couponMsg.className = "booking-coupon-msg error";
      }
    }
  }

  function roundToNextHour(d) {
    const date = new Date(d.getTime());
    date.setMinutes(0, 0, 0);
    date.setHours(date.getHours() + 1);
    return date;
  }

  function synchroniseRentalDates(isInitial = false) {
    const now = new Date();
    pickupInput.min = toLocalDateTime(now);

    let pDate = parseDateTime(pickupInput.value);
    let dDate = parseDateTime(dropInput.value);

    if (isInitial) {
      const urlPickup = params.get("pickup") || sessionStorageGet("crp_pickupDate");
      const urlDrop = params.get("drop") || sessionStorageGet("crp_dropDate");
      if (urlPickup) pDate = parseDateTime(urlPickup);
      if (urlDrop) dDate = parseDateTime(urlDrop);
    }

    if (!pDate || isNaN(pDate.getTime()) || pDate < now) {
      pDate = roundToNextHour(now);
    }

    // STRICT 24-HOUR MINIMUM DURATION: Drop must be at least 24 hours after pickup
    const minDrop = new Date(pDate.getTime() + 24 * 60 * 60 * 1000);
    if (!dDate || isNaN(dDate.getTime()) || dDate < minDrop) {
      dDate = minDrop;
    }

    pickupInput.value = toLocalDateTime(pDate);
    dropInput.min = toLocalDateTime(minDrop);
    dropInput.value = toLocalDateTime(dDate);

    try {
      sessionStorage.setItem("crp_pickupDate", pickupInput.value);
      sessionStorage.setItem("crp_dropDate", dropInput.value);
    } catch (_) {}
  }

  function calculateBooking() {
    const pickup = pickupInput ? pickupInput.value : "";
    const drop = dropInput ? dropInput.value : "";
    const withDriver = Boolean(driverInput && driverInput.checked);
    const paymentPlan =
      paymentPlanInputs.find((input) => input.checked)?.value || "advance";

    const calculation = calculateBookingPrice({
      vehicle,
      pickup,
      drop,
      withDriver,
      coupon: appliedCoupons,
      paymentPlan,
    });

    if (!calculation.valid) {
      totalsEl.innerHTML =
        '<div class="booking-error">' +
        (calculation.error || "Please select valid rental dates.") +
        "</div>";
      return null;
    }

    const {
      duration,
      hours,
      days,
      rentalTotal,
      driverTotal,
      securityDeposit,
      couponDiscount,
      finalAmount,
      advanceAmount,
      remainingAmount,
    } = calculation;

    const dayCount = Math.max(1, Number(days) || 1);
    const hourCount = Math.max(1, Number(hours) || (dayCount * 24));
    const fullDays = Math.floor(hourCount / 24);
    const remHours = hourCount % 24;
    let formattedDuration = "";
    if (fullDays > 0 && remHours > 0) {
      formattedDuration = `${fullDays} Day${fullDays > 1 ? "s" : ""} ${remHours} Hr${remHours > 1 ? "s" : ""} (${hourCount} hrs)`;
    } else if (fullDays > 0) {
      formattedDuration = `${fullDays} Day${fullDays > 1 ? "s" : ""} (${hourCount} hrs)`;
    } else {
      formattedDuration = `${hourCount} Hr${hourCount > 1 ? "s" : ""}`;
    }

    let html =
      '<div class="booking-totals__header"><span>PRICE BREAKDOWN</span><span>Duration: ' +
      formattedDuration +
      "</span></div>";
    html +=
      '<div class="booking-total-row"><span>Rental Charges (' +
      formattedDuration +
      ")</span><strong>₹" +
      formatCurrency(rentalTotal) +
      "</strong></div>";

    if (withDriver) {
      html +=
        '<div class="booking-total-row"><span>Driver Allowance</span><strong>₹' +
        formatCurrency(driverTotal) +
        "</strong></div>";
    }

    if (securityDeposit > 0) {
      html +=
        '<div class="booking-total-row" style="opacity:0.85;"><span>Refundable Deposit<small style="display:block; font-size:0.75rem; color:var(--text-sub)">(Payable at vehicle pickup • 100% Refundable)</small></span><strong>₹' +
        formatCurrency(securityDeposit) +
        "</strong></div>";
    }

    if (couponDiscount > 0) {
      const appliedLabels = appliedCoupons.map((c) => c.code).join(", ");
      html +=
        '<div class="booking-total-row" style="color: var(--kz-success, #34d399);"><span>Coupon Discount (' +
        appliedLabels +
        ')</span><strong style="color: var(--kz-success, #34d399);">-₹' +
        formatCurrency(couponDiscount) +
        "</strong></div>";
    }

    html +=
      '<div class="booking-total-row booking-total-row--grand"><span>Total Booking Amount</span><strong>₹' +
      formatCurrency(finalAmount) +
      "</strong></div>";
    html +=
      '<div class="booking-total-row booking-total-row--payment"><span>' +
      (paymentPlan === "advance"
        ? "Token Amount Payable Now"
        : "Full Amount Payable Now") +
      '<small style="display:block; font-size:0.75rem; color:var(--text-sub)">' +
      (paymentPlan === "advance"
        ? "Balance due at pickup: ₹" + formatCurrency(remainingAmount)
        : "100% booking confirmation") +
      "</small></span><strong>₹" +
      formatCurrency(advanceAmount) +
      "</strong></div>";

    totalsEl.innerHTML = html;
    return calculation;
  }

  if (couponApplyBtn && couponInput) {
    couponApplyBtn.addEventListener("click", () => {
      applyCouponCode(couponInput.value);
    });

    couponInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        applyCouponCode(couponInput.value);
      }
    });
  }

  if (resetBookingTimes) {
    resetBookingTimes.addEventListener("click", () => {
      const resetNow = new Date();
      const resetPickup = new Date(resetNow.getTime() + 60 * 60 * 1000);
      const resetDrop = new Date(resetPickup.getTime() + 24 * 60 * 60 * 1000);

      if (pickupInput._flatpickr) {
        pickupInput._flatpickr.setDate(resetPickup, true);
      } else {
        pickupInput.min = toLocalDateTime(resetNow);
        pickupInput.value = toLocalDateTime(resetPickup);
      }

      if (dropInput._flatpickr) {
        dropInput._flatpickr.setDate(resetDrop, true);
        dropInput._flatpickr.set("minDate", resetDrop);
      } else {
        dropInput.min = toLocalDateTime(resetDrop);
        dropInput.value = toLocalDateTime(resetDrop);
      }

      if (driverInput) driverInput.checked = false;
      paymentPlanInputs.forEach((input) => {
        input.checked = input.value === "advance";
      });
      document.querySelectorAll(".booking-payment-option").forEach((option) => {
        const radio = option.querySelector('input[name="paymentPlan"]');
        option.classList.toggle(
          "booking-payment-option--selected",
          radio && radio.value === "advance",
        );
      });

      appliedCoupons = [];
      renderAppliedCoupons();
      if (couponInput) couponInput.value = "";
      if (couponMsg) {
        couponMsg.textContent = "";
        couponMsg.className = "booking-coupon-msg";
      }

      try {
        sessionStorage.removeItem("crp_pickupDate");
        sessionStorage.removeItem("crp_dropDate");
        sessionStorage.removeItem("kruizly_applied_coupon");
        localStorage.removeItem("kruizly_temp_booking");
      } catch (_) {}

      if (window.history && window.history.replaceState) {
        const cleanParams = new URLSearchParams();
        if (vehicle && vehicle.regNo) cleanParams.set("reg", vehicle.regNo);
        const cleanUrl =
          window.location.pathname + "?" + cleanParams.toString();
        window.history.replaceState({}, document.title, cleanUrl);
      }

      calculateBooking();
    });
  }

  pickupInput.addEventListener("change", () => {
    if (pickupInput.value) {
      const pDate = parseDateTime(pickupInput.value);
      if (pDate && !isNaN(pDate.getTime())) {
        const minDrop = new Date(pDate.getTime() + 24 * 60 * 60 * 1000);
        dropInput.min = toLocalDateTime(minDrop);
        if (dropInput._flatpickr) {
          dropInput._flatpickr.set("minDate", minDrop);
        }
        const currentDrop = parseDateTime(dropInput.value);
        if (!currentDrop || isNaN(currentDrop.getTime()) || currentDrop < minDrop) {
          dropInput.value = toLocalDateTime(minDrop);
          if (dropInput._flatpickr) {
            dropInput._flatpickr.setDate(minDrop, true);
          }
        }
      }
    }
    calculateBooking();
  });
  pickupInput.addEventListener("input", calculateBooking);

  dropInput.addEventListener("change", () => {
    const pDate = parseDateTime(pickupInput.value);
    const dDate = parseDateTime(dropInput.value);
    if (pDate && !isNaN(pDate.getTime())) {
      const minDrop = new Date(pDate.getTime() + 24 * 60 * 60 * 1000);
      if (!dDate || isNaN(dDate.getTime()) || dDate < minDrop) {
        dropInput.value = toLocalDateTime(minDrop);
        if (dropInput._flatpickr) {
          dropInput._flatpickr.setDate(minDrop, true);
        }
        alert("Booking duration must be a minimum of 24 hours (1 full day). Drop time has been set to 24 hours from pickup.");
      }
    }
    calculateBooking();
  });
  dropInput.addEventListener("input", calculateBooking);
  driverInput && driverInput.addEventListener("change", calculateBooking);

  paymentPlanInputs.forEach((input) => {
    input.addEventListener("change", () => {
      document.querySelectorAll(".booking-payment-option").forEach((option) => {
        option.classList.toggle(
          "booking-payment-option--selected",
          option.contains(input) && input.checked,
        );
      });
      calculateBooking();
    });
  });

  const urlPaymentPlan = params.get("paymentPlan");
  if (urlPaymentPlan && paymentPlanInputs.some((p) => p.value === urlPaymentPlan)) {
    paymentPlanInputs.forEach((input) => {
      input.checked = input.value === urlPaymentPlan;
    });
    document.querySelectorAll(".booking-payment-option").forEach((option) => {
      const radio = option.querySelector('input[name="paymentPlan"]');
      option.classList.toggle(
        "booking-payment-option--selected",
        Boolean(radio && radio.checked),
      );
    });
  }

  synchroniseRentalDates(true);
  calculateBooking();

  const isAuthenticated = await checkAuth();
  if (isAuthenticated) {
    currentUser = getCurrentUser();
  }

  if (currentUser) {
    if (statusEl) statusEl.textContent = "";
    try {
      const vRes = await api.get(`/vehicles/${vehicle.regNo}`).catch(() => null);
      if (vRes?.vehicle && (vRes.vehicle.available === 0 || vRes.vehicle.available === false)) {
        throw new Error(
          "This vehicle was just marked unavailable. Please choose another car.",
        );
      }

      const uRes = await api.get("/users/me").catch(() => null);
      const userData = uRes?.user || {};

      if (userData.licenseStatus !== "verified" && licenseNote) {
        licenseNote.innerHTML =
          "<strong>Please Note</strong><span>Your driving licence is not verified yet. You can continue with booking, but please upload and verify it from your profile before pickup.</span>";
        licenseNote.classList.add("booking-license-note--warning");
      }
    } catch (error) {
      console.warn("Could not load user profile.", error);
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (!currentUser) {
      const isAuthed = await checkAuth();
      if (isAuthed) {
        currentUser = getCurrentUser();
      }
    }

    if (!currentUser) {
      const nextParams = new URLSearchParams();
      const vId = vehicle?.id || vehicle?.slug || vehicle?.regNo || queryId || sessionStorageGet("crp_selectedCarId");
      if (vId) nextParams.set("id", vId);
      if (pickupInput?.value) nextParams.set("pickup", pickupInput.value);
      if (dropInput?.value) nextParams.set("drop", dropInput.value);
      const next = "booking.html?" + nextParams.toString();
      window.location.href = "index.html?next=" + encodeURIComponent(next);
      return;
    }

    const now = new Date();
    const pDate = parseDateTime(pickupInput);
    const dDate = parseDateTime(dropInput);

    if (!pDate || isNaN(pDate.getTime()) || pDate < new Date(now.getTime() - 2 * 60 * 1000)) {
      if (statusEl) {
        statusEl.textContent = "Pickup date cannot be in the past. Please select an upcoming date.";
        statusEl.classList.add("form-status--error");
      }
      return;
    }

    const minDrop = new Date(pDate.getTime() + 24 * 60 * 60 * 1000);
    if (!dDate || isNaN(dDate.getTime()) || dDate < minDrop) {
      if (statusEl) {
        statusEl.textContent = "Booking duration must be a minimum of 24 hours (1 full day). Drop time adjusted automatically.";
        statusEl.classList.add("form-status--error");
      }
      dropInput.value = toLocalDateTime(minDrop);
      calculateBooking();
      return;
    }

    const calculation = calculateBooking();
    if (!calculation || !calculation.valid) {
      if (statusEl) {
        statusEl.textContent = calculation
          ? calculation.error
          : "Please review the booking schedule before proceeding.";
        statusEl.classList.add("form-status--error");
      }
      return;
    }

    const submitButton = form.querySelector('button[type="submit"]');
    if (submitButton) submitButton.disabled = true;

    if (statusEl) {
      statusEl.textContent = "Saving your booking…";
      statusEl.classList.remove("form-status--error");
    }

    try {
      let userData = {};
      try {
        const uRes = await api.get("/users/me").catch(() => null);
        if (uRes?.user) userData = uRes.user;
      } catch (uErr) {
        console.warn("Could not read user profile:", uErr);
      }

      const numericBookingId = generateNumericBookingId();

      const bookingRecord = {
        bookingId: numericBookingId,
        bookingNumber: numericBookingId,
        userId: currentUser.uid,
        userName:
          userData.name || currentUser.displayName || currentUser.email || "",
        userEmail: currentUser.email || "",
        userPhone: userData.phone || null,

        carId: vehicle.regNo,
        vehicleReg: vehicle.regNo,
        vehicleName: vehicle.brand + " " + vehicle.model,
        vehicleCategory: vehicle.category,

        pickupDate: pDate ? `${toLocalDateTime(pDate).replace("T", " ")}:00` : new Date().toISOString(),
        dropDate: dDate ? `${toLocalDateTime(dDate).replace("T", " ")}:00` : new Date().toISOString(),
        duration: calculation.duration.formattedDuration,
        durationDays: calculation.days,
        days: calculation.days,
        hours: calculation.hours,

        withDriver: calculation.withDriver,
        dayRate: vehicle.priceDay,
        hourlyRate: calculation.hourlyRate,
        driverRate: vehicle.driverPrice || 2000,
        driverHourlyRate: calculation.driverHourlyRate,
        securityDeposit: calculation.securityDeposit,
        baseAmount: calculation.rentalTotal,
        couponCode: calculation.appliedCoupons?.length
          ? calculation.appliedCoupons.map((c) => c.code).join(", ")
          : calculation.couponApplied
            ? calculation.couponApplied.code
            : null,
        couponDiscount: calculation.couponDiscount || 0,
        finalAmount: calculation.finalAmount,
        totalAmount: calculation.finalAmount,

        paymentPlan: calculation.paymentPlan,
        advanceAmount: calculation.advanceAmount,
        remainingAmount: calculation.remainingAmount,
        remainingBalance: calculation.remainingAmount,

        pickup_hub_id: Number(vehicle.hubId || vehicle.hub_id || 0) || null,
        drop_hub_id: Number(vehicle.hubId || vehicle.hub_id || 0) || null,
        pickupHubName: vehicle.hubName || "",
        dropHubName: vehicle.hubName || "",
        location: vehicle.hubName || vehicle.location || "",
        pickupLocation: vehicle.hubName || vehicle.location || "",
        dropLocation: vehicle.hubName || vehicle.location || "",

        status: "pending_payment",
        bookingStatus: "pending_payment",
        paymentStatus: "pending_payment",
        paymentRef: null,
      };

      // ── STEP 1: POST to MySQL backend — source of truth ──────────────
      let confirmedBookingId = numericBookingId;
      try {
        const createRes = await api.post("/bookings/create", bookingRecord);
        if (createRes?.bookingId) {
          confirmedBookingId          = createRes.bookingId;
          bookingRecord.bookingId     = confirmedBookingId;
          bookingRecord.bookingNumber = confirmedBookingId;
        }
      } catch (apiErr) {
        console.error("Backend booking save failed:", apiErr);
        if (statusEl) {
          statusEl.textContent =
            "Could not save your booking. Please check your connection and try again.";
          statusEl.classList.add("form-status--error");
        }
        if (submitButton) submitButton.disabled = false;
        return;
      }

      // ── STEP 2: Cache in sessionStorage as a fast-path for payment page ──
      try {
        sessionStorage.setItem("kruizly_pending_booking", JSON.stringify(bookingRecord));
        sessionStorage.removeItem("crp_pickupDate");
        sessionStorage.removeItem("crp_dropDate");
      } catch (_) {}

      // ── STEP 3: Redirect to payment with the real server-issued bookingId ──
      const paymentParams = new URLSearchParams();
      paymentParams.set("booking", confirmedBookingId);
      paymentParams.set("plan", calculation.paymentPlan);
      window.location.href = "payment.html?" + paymentParams.toString();
    } catch (error) {
      console.error("Booking preparation failed:", error);
      if (statusEl) {
        statusEl.textContent =
          (error && error.message) ||
          "Couldn't prepare the booking. Please try again.";
        statusEl.classList.add("form-status--error");
      }
      if (submitButton) submitButton.disabled = false;
    }
  });
}
